package org.techtown.tamp;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.naver.maps.geometry.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class PedestrianRouteFinder extends AsyncTask<Void, Void, JsonArray> {

    private static final String TAG = "PedestrianRouteFinder";

    private static final String TMAP_API_KEY = "tnXBUpdf4D73FGfHYZLMj5M3k3Qwkcsl8GNCwrRS";
    private static final String TMAP_API_URL = "https://apis.openapi.sk.com/tmap/routes/pedestrian?version=1&format=json";

    private final double startX;
    private final double startY;
    private final String startName;
    private final double endX;
    private final double endY;
    private final String endName;

    private final OnRouteFoundListener listener;

    public PedestrianRouteFinder(double startX, double startY, String startName,
                                 double endX, double endY, String endName,
                                 OnRouteFoundListener listener) {
        this.startX = startX;
        this.startY = startY;
        this.startName = startName;
        this.endX = endX;
        this.endY = endY;
        this.endName = endName;
        this.listener = listener;
    }




    @Override
    protected JsonArray doInBackground(Void... voids) {
        OkHttpClient client = new OkHttpClient();

        String url = TMAP_API_URL + "&appKey=" + TMAP_API_KEY +
                "&startX=" + startX + "&startY=" + startY + "&startName=" + startName +
                "&endX=" + endX + "&endY=" + endY + "&endName=" + endName;

        Request request = new Request.Builder()
                .url(url)
                .build();

        try {
            Response response = client.newCall(request).execute();
            if (!response.isSuccessful()) {
                throw new Exception("Unexpected response code: " + response.code());
            }

            JsonObject jsonResponse = JsonParser.parseString(response.body().string()).getAsJsonObject();

//            Log.d(TAG, jsonResponse.toString());

            JsonArray features = jsonResponse.getAsJsonArray("features");

            return features;

        } catch (JSONException e) {
            Log.e(TAG, "Error parsing JSON response", e);
        } catch (Exception e) {
            Log.e(TAG, "Error fetching route from TMap API", e);
        }

        return null;
    }




    @Override
    protected void onPostExecute(JsonArray features) {

//        List<List<Integer>> latLngList = new ArrayList<>();
        JsonArray latLngList = new JsonArray();

        JsonPrimitive linString = new JsonPrimitive("LineString");


        for (int i = 0; i < features.size(); i++) {
            try {
//
                JsonObject geometry = features.get(i).getAsJsonObject().getAsJsonObject("geometry");


                if (geometry.get("type").equals(linString)) {
//
                    JsonArray coordinates = geometry.getAsJsonArray("coordinates");
                    latLngList.addAll(coordinates);

                }

            } catch (Exception e) {
                Log.e(TAG, e.getMessage());
            }

        }


        if(latLngList!=null){
            Log.d("경로 " ,"찾았습니다");
            listener.onRouteFound(latLngList);
        }
         else {
            Log.d("경로 " ,"못 찾았습니다");

            listener.onRouteNotFound();
        }

    }

    public interface OnRouteFoundListener {
        void onRouteFound(JsonArray coordinates);
        void onRouteNotFound();
    }
}
