package org.techtown.tamp;


import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.map.CameraPosition;
import com.naver.maps.map.CameraUpdate;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.overlay.PathOverlay;
import org.techtown.tamp.LocationUtils;


import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity implements PedestrianRouteFinder.OnRouteFoundListener, OnMapReadyCallback {

    private NaverMap naverMap;
    private LocationUtils locationUtils;

    private Marker marker = new Marker();
    private PathOverlay path;
    private List<LatLng> latLngs = new ArrayList<>();

    private String searchText;


    private EditText searchEditText;



    double startX = 127.0467338;
    double startY = 37.2805057;
    String startName = "출발지 이름";
    double endX = 0;
    double endY =0;
    String endName = "도착지 이름";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        인터넷 연결상태
//
//        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
//
//        if (connectivityManager != null)
//
//        {
//            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
//
//            if (networkInfo != null && networkInfo.isConnected()) {
//                Log.d("연결", "됨");
//                // 인터넷이 연결된 상태입니다.
//            } else {
//                Log.d("연결", "안됨");
//
//                // 인터넷이 연결되지 않은 상태입니다.
//            }
//        }




        super.onCreate(savedInstanceState);


        Intent POIintent = new Intent(MainActivity.this, POIActivity.class);
        startActivity(POIintent);

        Intent intent = getIntent();
        if (intent != null) {
            endName = intent.getStringExtra("POIName");
        }

        setContentView(R.layout.activity_main);
        endY = getIntent().getDoubleExtra("frontLat", 0);
        endX = getIntent().getDoubleExtra("frontLon", 0);

        locationUtils = new LocationUtils(this);

        Log.d("location","내위치 : "+ startX+ ", "+startY);

        //값이 전달됬나 확인, 나중에 삭제
        Toast.makeText(MainActivity.this, ""+endY, Toast.LENGTH_SHORT).show();

        if(endY != 0) {
            PedestrianRouteFinder routeFinder = new PedestrianRouteFinder(startX, startY, startName, endX, endY, endName, this);
            routeFinder.execute();


            MapFragment mapFragment = (MapFragment) getSupportFragmentManager().findFragmentById(R.id.map_fragment);
            mapFragment.getMapAsync(this);
        }

    }

    @Override
    public void onRouteFound(JsonArray coordinates) {
        // 도보 경로를 찾았을 때 처리
        Toast.makeText(this, "경로를 찾았습니다.", Toast.LENGTH_SHORT).show();
        DecimalFormat df = new DecimalFormat("0.00000");

        // coordinates를 사용하여 지도에 경로 표시 등을 구현할 수 있습니다.

        //전체경로
        for (int i = 0; i < coordinates.size(); i++) {
            JsonArray coords = coordinates.get(i).getAsJsonArray();
            LatLng latLng = new LatLng(Double.parseDouble(df.format(coords.get(1).getAsDouble())), Double.parseDouble(df.format(coords.get(0).getAsDouble())));

            latLngs.add(latLng);

        }
//        Log.d("latLngs : ", Arrays.toString(latLngs.toArray()));



        path = new PathOverlay();
        path.setCoords(latLngs);
        path.setColor(Color.RED); // 선 색상 지정
        path.setWidth(5); // 선 두께 지정
//        path.setMap(naverMap);
    }



    @Override
    public void onRouteNotFound() {
        // 도보 경로를 찾지 못했을 때 처리
        Toast.makeText(this, "도보 경로를 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {
        this.naverMap = naverMap;

        naverMap.setCameraPosition(new CameraPosition(new LatLng(startY, startX), 16));


    }

    //지도 이동
    public void moveMap(double latitude, double longitude){


        marker.setPosition(new LatLng(latitude, longitude));
        marker.setMap(naverMap);
        naverMap.moveCamera(CameraUpdate.scrollTo(new LatLng(latitude, longitude)));
//        removePath(latitude,longitude);

    }
    //경로 삭제
    public void removePath(double latitude, double longitude){


        if(!latLngs.isEmpty())
        {
        for(int i =0; i<10 ; i++){
            if(latitude-0.00005<=latLngs.get(0).latitude||
                    latLngs.get(0).latitude<=latitude+0.00005||
                    latLngs.get(0).longitude<=longitude+0.00005||
                    latLngs.get(0).longitude>=longitude-0.00005){

                Log.d("내위치 remove : ", (latitude-0.00005)+"  "+(latitude)+"  "+(longitude+0.00005)+"  "+(longitude));

                latLngs.remove(0);
            }
            else{
                break;
            }

        }
        Log.d("latLngs : ", Arrays.toString(latLngs.toArray()));

        path.setCoords(latLngs);

        }
//        for(int i =0; i<10 ; i++){
//            if(latitude-0.00005<=latLngs.get(0).latitude&&
//                    latLngs.get(0).latitude<=latitude+0.00005&&
//                    latLngs.get(0).longitude<=longitude+0.00005&&
//                    latLngs.get(0).longitude>=longitude-0.00005){
//                latLngs.remove(0);
//            }
//            else{
//                break;
//            }
//
//        }
//        Log.d("latLngs : ", Arrays.toString(latLngs.toArray()));

//        path.setCoords(latLngs);



    }


    //내 위치 받기

    // 위치 정보를 수신하면 호출되는 메서드
        public void onLocationReceived(double latitude, double longitude) {

            startX = longitude;
            startY = latitude;
        }

//
}
