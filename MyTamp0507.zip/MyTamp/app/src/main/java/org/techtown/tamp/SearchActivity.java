package org.techtown.tamp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SearchActivity extends AppCompatActivity {

    private EditText searchEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        // 검색 창 EditText 가져오기
        searchEditText = findViewById(R.id.searchEditText);

        // 검색 버튼 클릭 이벤트 처리
        Button searchButton = findViewById(R.id.searchButton);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchText = searchEditText.getText().toString().trim();

                // 검색어를 메인 액티비티로 전달
                Intent intent = new Intent(SearchActivity.this, MainActivity.class);
                intent.putExtra("searchText", searchText);
                startActivity(intent);
                finish();
            }
        });

    }
}